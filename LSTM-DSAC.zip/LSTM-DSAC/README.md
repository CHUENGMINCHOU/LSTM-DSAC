## Dependencies
1. [Python-RVO2](https://github.com/sybrenstuvel/Python-RVO2) library

pip3 install -e .

## Commands
1. Train a policy.
```
python3 train.py --policy sa_sac_rl

```
2. Run policy for one episode and visualize the result.
```
python3 test.py --policy sa_sac_rl --output_dir ENVS/data/output --phase test --visualize --test_case 0
```
3. Visualize a test case.
```
python3 test.py --policy sa_sac_rl --model_dir ENVS/data/output --phase test --visualize --test_case 0

```
4. Plot training curve.
```
python3 plot.py ENVS/data/output/*.log
```
