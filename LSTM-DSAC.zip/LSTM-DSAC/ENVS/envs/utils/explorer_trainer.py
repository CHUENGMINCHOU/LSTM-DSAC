import logging
import copy
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import math
import os
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

from torch.distributions.categorical import Categorical
from torch.autograd import Variable
from torch.utils.data import DataLoader
from ENVS.envs.utils.info import *
from ENVS.envs.utils.state import JointState


def average(input_list):
    if input_list:
        return sum(np.array(input_list).tolist()) / len(input_list)
    else:
        return 0

class Explorer(object): # run k epis to update buffer in training; to test the model in eva/testing
    def __init__(self, args, env, robot, device, memory, agent_policy):
        self.env = env
        self.robot = robot
        self.device = device
        #self.robot_policy = policy
        #self.model = model
        #self.model_critic = critic
        #self.args.batch_size = args.batch_size
        self.memory = memory
        #self.capacity = capacity
        self.batch_size = args.batch_size
        #self.trainer = Trainer(self.model, self.buffer, self.device, self.batch_size, self.robot_policy)
        #self.train_batches = train_batches

        self.total_steps = []
        self.total_rewards = []

        self.args = args
        self.target_update_interval = args.target_update_interval
        self.gamma = args.gamma
        self.tau = args.tau
        self.alpha = args.alpha

        self.agent_policy = agent_policy
        self.input_dim = agent_policy.input_dim()
        self.action_space = agent_policy.input_dim()

        self.policy_network = agent_policy.policy_network
        self.policy_network_optim = agent_policy.policy_network_optim
        self.critic = agent_policy.critic
        self.critic_target = agent_policy.critic_target
        self.critic_optim = agent_policy.critic_optim
        self.automatic_entropy_tuning = agent_policy.automatic_entropy_tuning

        self.target_entropy = agent_policy.target_entropy
        self.log_alpha = agent_policy.log_alpha
        self.alpha_optim = agent_policy.alpha_optim

    def compute_returns(self, rewards, masks):
        R = 0
        returns = []
        for i in reversed(range(len(rewards))):
            #gamma_bar = pow(self.gamma, self.robot.time_step * self.robot.v_pref)
            R = rewards[i] + self.gamma * R * masks[i]
            returns.insert(0, R)
        return returns

    def update_buffer(self, states, actions_indice, rewards, next_states, masks):
        positive_reward = False
        for r in rewards:
            #if r > 0:
            if True:
                positive_reward = True
                break
        if positive_reward:
            for (state_, action_indice_, reward_, next_state_, mask_) in zip(states, actions_indice, rewards, next_states, masks):
                #print('------------------', action_indice_.squeeze(0))
                self.memory.push(state_, action_indice_.squeeze(0), reward_, next_state_, mask_)

    def soft_update(self, target, source, tau):
        for target_param, param in zip(target.parameters(), source.parameters()):
            target_param.data.copy_(target_param.data * (1.0 - tau) + param.data * tau)

    def hard_update(self, target, source):
        for target_param, param in zip(target.parameters(), source.parameters()):
            target_param.data.copy_(param.data)

    def update_parameters(self, memory, batch_size, updates):
        state_batch, action_indice_batch, reward_batch, next_state_batch, mask_batch = memory.sample(batch_size=batch_size)
        state_batch = torch.FloatTensor(state_batch).to(self.device)
        next_state_batch = torch.FloatTensor(next_state_batch).to(self.device)
        action_indice_batch = torch.FloatTensor(action_indice_batch).to(self.device)#.unsqueeze(0)
        reward_batch = torch.FloatTensor(reward_batch).to(self.device).unsqueeze(1)#for reward case
        #reward_batch = torch.FloatTensor(reward_batch).to(self.device)#for return case
        mask_batch = torch.FloatTensor(mask_batch).to(self.device)#.unsqueeze(1)


        with torch.no_grad():
            #calculate next target Q
            next_state_action_prob, next_state_log_action_prob, _ = self.policy_network.sample(next_state_batch)
            qf1_next_target, qf2_next_target = self.critic_target(next_state_batch)
            min_qf_next_target = (next_state_action_prob * (torch.min(qf1_next_target, qf2_next_target) - self.alpha * next_state_log_action_prob)).sum(dim=1, keepdim=True)
            #gamma_bar = pow(self.gamma, self.robot.time_step * self.robot.v_pref)
            next_q_value = reward_batch + mask_batch * self.gamma * (min_qf_next_target)
            #print('------------', reward_batch.shape)
            #print('************', next_state_action)

        #calculate current Q
        qf1, qf2 = self.critic(state_batch)  # Two Q-functions to mitigate positive bias in the policy improvement step
        #print('---------', qf1.shape, '*********', action_indice_batch.shape)
        qf1 = qf1.gather(1, action_indice_batch.long())
        qf2 = qf2.gather(1, action_indice_batch.long())

        #calculate critic loss
        qf1_loss = F.mse_loss(qf1, next_q_value)  # JQ = 𝔼(st,at)~D[0.5(Q1(st,at) - r(st,at) - γ(𝔼st+1~p[V(st+1)]))^2]
        qf2_loss = F.mse_loss(qf2, next_q_value)  # JQ = 𝔼(st,at)~D[0.5(Q1(st,at) - r(st,at) - γ(𝔼st+1~p[V(st+1)]))^2]
        #print('---------', qf1.shape, '*********', next_q_value.shape)
        qf_loss = qf1_loss + qf2_loss

        self.critic_optim.zero_grad()
        qf_loss.backward()
        self.critic_optim.step()

        #calculate policy(actor) loss
        pi, log_pi, _ = self.policy_network.sample(state_batch)
        with torch.no_grad():
            qf1_pi, qf2_pi = self.critic(state_batch)
            min_qf_pi = torch.min(qf1_pi, qf2_pi)
        entropies = -torch.sum(pi * log_pi, dim=1, keepdim=True)
        q_exp = torch.sum(torch.min(qf1_pi, qf2_pi) * pi, dim=1, keepdim=True)
        policy_loss = (-q_exp - self.alpha * entropies).mean()

        self.policy_network_optim.zero_grad()
        policy_loss.backward()
        self.policy_network_optim.step()
        

        if self.automatic_entropy_tuning:
            #alpha_loss = -(self.log_alpha * (log_pi + self.target_entropy).detach()).mean()
            alpha_loss = -(self.log_alpha * (self.target_entropy - entropies).detach()).mean()
            #print('---------', self.target_entropy)
            self.alpha_optim.zero_grad()
            alpha_loss.backward()
            self.alpha_optim.step()

            self.alpha = self.log_alpha.exp()
            #alpha_tlogs = self.alpha.clone() # For TensorboardX logs
        else:
            alpha_loss = torch.tensor(0.).to(self.device)
            #alpha_tlogs = torch.tensor(self.alpha) # For TensorboardX logs

        #print('---------', qf_loss, '*********', policy_loss, '++++++++', alpha_loss)

        if updates % self.target_update_interval == 0:
            self.soft_update(self.critic_target, self.critic, self.tau)

        #return qf1_loss.item(), qf2_loss.item(), policy_loss.item(), alpha_loss.item(), alpha_tlogs.item()
    

    # @profile
    def run_k_episodes(self, k, phase, update_memory=False,  episode=None, print_failure=False):
        self.robot.policy.set_phase(phase)
        success_times = []
        collision_times = []
        timeout_times = []
        success = 0
        collision = 0
        timeout = 0
        too_close = 0
        min_dist = []
        cumulative_rewards = []
        collision_cases = []
        timeout_cases = []

        #ada_ent = self.adaptive_entropy(episode)
        updates = 0
        episode_steps = 0

        for i in range(k):
            ob = self.env.reset(phase)
            done = False
            states = []
            #states_np = []
            actions = []
            actions_indice = []
            rewards = []
            next_states = []
            #dones = []
            masks = []

            while not done:
                action, action_indice, action_prob, state_joint = self.robot.act(ob)
                #print('action_indice', action_indice)
                state = self.robot.policy.last_state 
                #robot-centred state tensor [batch_size, 61]
                states.append(state)

                #next state version_2
                next_self_state = self.agent_policy.propagate(state_joint.self_state, action)
                ob_next_pred, _, _, _ = self.env.onestep_lookahead(action)
                next_state_joint = JointState(next_self_state, ob_next_pred)
                next_state = self.agent_policy.transform(next_state_joint)
                next_states.append(next_state)

                ob_next, reward, done, info = self.env.step(action)
                #print('-----', state.shape)
                #state_np = np.array(state)
                #states_np.append(state_np)
                #print('states', states)

                actions_indice.append(action_indice)
                #log_probs.append(log_prob)
                #values.append(value)
                rewards.append(torch.tensor(reward, dtype=torch.float32, device=self.device))
                #dones.append(done)
                mask = float(not done)
                masks.append(torch.tensor([1-done], dtype=torch.float32, device=self.device))
                ob = ob_next

                #if args.start_steps > total_numsteps:
                #    action = env.action_space.sample()  # Sample random action
                #else:
                #    action = agent.select_action(state)  # Sample action from policy

                if len(self.memory) > self.batch_size:
                    # Number of updates per step in environment
                    for i in range(self.args.updates_per_step):
                        # Update parameters of all the networks
                        self.update_parameters(self.memory, self.batch_size, updates)
                        updates += 1

                #next_state, reward, done, _ = env.step(action) # Step
                episode_steps += 1
                #total_numsteps += 1
                #episode_reward += reward
                #mask = 1 if episode_steps == env._max_episode_steps else float(not done)

                #print('*******')
                #print('--------', next_state)
                #if update_memory == True:
                #    self.memory.push(state, action_indice, reward, next_state, mask)

                if isinstance(info, Danger):
                    too_close += 1
                    min_dist.append(info.min_dist)
            if isinstance(info, ReachGoal):
                success += 1
                success_times.append(self.env.global_time)
            elif isinstance(info, Collision):
                collision += 1
                collision_cases.append(i)
                collision_times.append(self.env.global_time)
            elif isinstance(info, Timeout):
                timeout += 1
                timeout_cases.append(i)
                timeout_times.append(self.env.time_limit)
            else:
                raise ValueError('Invalid end signal from environment')

            # visualize the training data
            #self.env.render('video', self.args.video_file)

            #returns = self.compute_returns(rewards, masks)
            #print('--------', rewards, '******', returns)
            if update_memory == True:
                self.update_buffer(states, actions_indice, rewards, next_states, masks)

            cumulative_rewards.append(sum([pow(self.gamma, t * self.robot.time_step * self.robot.v_pref)
                                           * reward for t, reward in enumerate(rewards)]))
            avg_cumulative_rewards = average(cumulative_rewards)

        success_rate = success / k
        collision_rate = collision / k
        assert success + collision + timeout == k
        avg_nav_time = sum(success_times) / len(success_times) if success_times else self.env.time_limit

        extra_info = '' if episode is None else 'in episode {} '.format(episode)
        logging.info('{:<5} {}has success rate: {:.2f}, collision rate: {:.2f}, nav time: {:.2f}, total reward: {:.4f}'.
                     format(phase.upper(), extra_info, success_rate, collision_rate, avg_nav_time,
                            average(cumulative_rewards)))

        if phase in ['val', 'test']:
            total_time = sum(success_times + collision_times + timeout_times) * self.robot.time_step
            logging.info('Frequency of being in danger: %.2f and average min separate distance in danger: %.2f',
                         too_close / total_time, average(min_dist))

        if print_failure:
            logging.info('Collision cases: ' + ' '.join([str(x) for x in collision_cases]))
            logging.info('Timeout cases: ' + ' '.join([str(x) for x in timeout_cases]))

    
